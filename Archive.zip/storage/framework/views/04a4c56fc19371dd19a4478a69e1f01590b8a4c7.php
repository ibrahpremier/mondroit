
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/swiper/swiper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/magnific-popup/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/colors/theme-color-1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <?php /**PATH /Users/ibrahim/PROJETS/Laravel/mondroit/resources/views/includes/head_import.blade.php ENDPATH**/ ?>
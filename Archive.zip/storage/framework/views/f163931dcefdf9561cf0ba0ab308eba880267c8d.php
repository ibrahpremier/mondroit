

    <script src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fontawesome-all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/typed.js/typed.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/waypoints/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/waypoints/sticky.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/swiper/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/particles.js/particles.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/particles.js/particles.settings.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/parsley/parsley.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/parallax/parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/retinajs/retina.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/menu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script><?php /**PATH /Users/ibrahim/PROJETS/Laravel/mondroit/resources/views/includes/script_import.blade.php ENDPATH**/ ?>

    {{-- <link href="https://fonts.googleapis.com/css?family=Cabin:400,400i,500i,700%7CRoboto:400,500,700" rel="stylesheet"> --}}
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugins/swiper/swiper.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugins/magnific-popup/magnific-popup.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/responsive.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/colors/theme-color-1.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/custom.css')}}">
    {{-- <link rel="stylesheet" href="assets/css/login.css"> --}}